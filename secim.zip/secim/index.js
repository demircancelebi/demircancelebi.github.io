const fs = require('fs');

fs.readFile('input.json', 'utf-8', function(err, file) {
  const obj = JSON.parse(file);
  const cities = {};
  Object.keys(obj.process).forEach((k, i) => {
    const v = obj.process[k];
    Object.keys(v).forEach((key, index) => {
      const elem = v[key];
      if (!cities[elem.city]) {
        cities[elem.city] = [elem];
      } else {
        cities[elem.city].push(elem);
      }
    })
  });

  const cityAnswers = {};

  Object.keys(cities).forEach(k => {
    const city = cities[k];
    cityAnswers[k] = [];
    city.forEach(elem => {
      if (elem['001']) {
        cityAnswers[k].push(elem['001']);
      }
    })
  });

  const lens = {};
  const trueLens = {};
  const l = obj['process-status'].checkLists['001'].list;
  const q = Object.keys(l).map(k => l[k].text);

  Object.keys(cityAnswers).forEach(k => {
    lens[k] = cityAnswers[k].length;
    trueLens[k] = {
      cityId: k,
      len: cityAnswers[k].length,
      [q[0]]: (cityAnswers[k].filter(a => a['01'] === true).length * 100) / cityAnswers[k].length,
      [q[1]]: (cityAnswers[k].filter(a => a['02'] === true).length * 100) / cityAnswers[k].length,
      [q[2]]: (cityAnswers[k].filter(a => a['03'] === true).length * 100) / cityAnswers[k].length,
      [q[3]]: (cityAnswers[k].filter(a => a['04'] === true).length * 100) / cityAnswers[k].length,
    };
  });

  Object.keys(trueLens).forEach(k => {
    fs.appendFile('results.json', `${JSON.stringify(trueLens[k])}\n`);
  });
})