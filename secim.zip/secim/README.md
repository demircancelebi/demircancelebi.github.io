# secim
You can change `input.json` and run the code again.

## To run
- Install node.js and npm
- Run `node index.js`
- Run `npm install -g json2csv`
- Run `json2csv -i results.json -o results.csv`
